<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>AboutEpsonScan2Dialog</name>
    <message>
        <location filename="src/Standalone/aboutepsonscan2dialog.ui" line="14"/>
        <source>VERSION_001</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/aboutepsonscan2dialog.ui" line="91"/>
        <source>LINUX_VERSION_001</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/aboutepsonscan2dialog.ui" line="104"/>
        <source>VERSION_002</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/aboutepsonscan2dialog.ui" line="121"/>
        <source>TC_PREVIEW_001</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AddPageDialog</name>
    <message>
        <location filename="src/Standalone/addpagedialog.ui" line="14"/>
        <source>ADDPAGE_001</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/addpagedialog.ui" line="30"/>
        <source>ADDPAGE_002</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/addpagedialog.ui" line="43"/>
        <source>ADDPAGE_006</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/addpagedialog.ui" line="56"/>
        <source>ADDPAGE_005</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/addpagedialog.ui" line="72"/>
        <source>ADDPAGE_004</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AdministratorPasswordInputDialog</name>
    <message>
        <location filename="src/Standalone/administratorpasswordinputdialog.ui" line="14"/>
        <source>ES2U_MAIN_069</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/administratorpasswordinputdialog.ui" line="29"/>
        <source>ES2U_MAIN_046</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/administratorpasswordinputdialog.ui" line="42"/>
        <source>ES2U_MAIN_047</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/administratorpasswordinputdialog.ui" line="55"/>
        <source>ES2U_MAIN_070</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/administratorpasswordinputdialog.ui" line="74"/>
        <source>ACCESSCONTROL_006</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/administratorpasswordinputdialog.ui" line="112"/>
        <source>:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AdministratorPasswordInputForUKSecurityDialog</name>
    <message>
        <location filename="src/Standalone/administratorpasswordinputforuksecuritydialog.ui" line="14"/>
        <source>ES2U_MAIN_069</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/administratorpasswordinputforuksecuritydialog.ui" line="29"/>
        <source>ES2U_MAIN_046</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/administratorpasswordinputforuksecuritydialog.ui" line="42"/>
        <source>ES2U_MAIN_047</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/administratorpasswordinputforuksecuritydialog.ui" line="55"/>
        <source>ACCESSCONTROL_006</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/administratorpasswordinputforuksecuritydialog.ui" line="74"/>
        <source>:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/administratorpasswordinputforuksecuritydialog.ui" line="112"/>
        <source>ES2U_MAIN_070</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/administratorpasswordinputforuksecuritydialog.ui" line="131"/>
        <source>ES2U_MAIN_071</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AutomaticFeedingModeDialog</name>
    <message>
        <location filename="src/Standalone/automaticfeedingmodedialog.ui" line="14"/>
        <source>MAINSETTING_007</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/automaticfeedingmodedialog.ui" line="30"/>
        <source>AUTOFEEDMODE_003</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/automaticfeedingmodedialog.ui" line="43"/>
        <source>AUTOFEEDMODE_002</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/automaticfeedingmodedialog.ui" line="115"/>
        <source>PROGRESS_008</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/automaticfeedingmodedialog.ui" line="131"/>
        <source>PROGRESS_017</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ConfigurationDialog</name>
    <message>
        <location filename="src/Standalone/configurationdialog.ui" line="17"/>
        <source>CONFIG_001</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/configurationdialog.ui" line="37"/>
        <source>ES2U_MAIN_004</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/configurationdialog.ui" line="49"/>
        <source>ES2U_MAIN_005</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/configurationdialog.ui" line="81"/>
        <location filename="src/Standalone/configurationdialog.ui" line="94"/>
        <source>xxxxx</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/configurationdialog.ui" line="126"/>
        <source>ES2U_MAIN_006</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/configurationdialog.ui" line="132"/>
        <source>CONFIG_GENERAL_001</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/configurationdialog.ui" line="144"/>
        <source>CONFIG_GENERAL_002</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/configurationdialog.ui" line="167"/>
        <source>CONFIG_GENERAL_005</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/configurationdialog.ui" line="180"/>
        <source>CONFIG_SAVEFILE_002</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/configurationdialog.ui" line="193"/>
        <source>CONFIG_SCAN_004</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/configurationdialog.ui" line="225"/>
        <source>CONFIG_PREVIEW_002</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/configurationdialog.ui" line="257"/>
        <source>CONFIG_PREVIEW_001</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/configurationdialog.ui" line="263"/>
        <source>ES2U_MAIN_009</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/configurationdialog.ui" line="275"/>
        <source>ES2U_MAIN_010</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/configurationdialog.ui" line="287"/>
        <source>ES2U_MAIN_011</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/configurationdialog.ui" line="300"/>
        <location filename="src/Standalone/configurationdialog.ui" line="329"/>
        <location filename="src/Standalone/configurationdialog.ui" line="355"/>
        <location filename="src/Standalone/configurationdialog.ui" line="381"/>
        <location filename="src/Standalone/configurationdialog.ui" line="394"/>
        <location filename="src/Standalone/configurationdialog.ui" line="433"/>
        <location filename="src/Standalone/configurationdialog.ui" line="446"/>
        <location filename="src/Standalone/configurationdialog.ui" line="472"/>
        <location filename="src/Standalone/configurationdialog.ui" line="682"/>
        <location filename="src/Standalone/configurationdialog.ui" line="734"/>
        <location filename="src/Standalone/configurationdialog.ui" line="776"/>
        <location filename="src/Standalone/configurationdialog.ui" line="853"/>
        <location filename="src/Standalone/configurationdialog.ui" line="895"/>
        <location filename="src/Standalone/configurationdialog.ui" line="974"/>
        <location filename="src/Standalone/configurationdialog.ui" line="1032"/>
        <source>ES2U_MAIN_008</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/configurationdialog.ui" line="313"/>
        <location filename="src/Standalone/configurationdialog.ui" line="316"/>
        <source>ES2U_MAIN_012</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/configurationdialog.ui" line="342"/>
        <source>ES2U_MAIN_013</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/configurationdialog.ui" line="368"/>
        <source>ES2U_MAIN_014</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/configurationdialog.ui" line="407"/>
        <source>ES2U_MAIN_054</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/configurationdialog.ui" line="420"/>
        <source>ES2U_MAIN_051</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/configurationdialog.ui" line="459"/>
        <source>ES2U_MAIN_015</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/configurationdialog.ui" line="485"/>
        <source>ES2U_MAIN_016</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/configurationdialog.ui" line="669"/>
        <source>ES2U_MAIN_058</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/configurationdialog.ui" line="709"/>
        <source>ES2U_MAIN_060</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/configurationdialog.ui" line="721"/>
        <location filename="src/Standalone/configurationdialog.ui" line="840"/>
        <location filename="src/Standalone/configurationdialog.ui" line="961"/>
        <location filename="src/Standalone/configurationdialog.ui" line="1491"/>
        <source>ES2U_MAIN_020</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/configurationdialog.ui" line="747"/>
        <location filename="src/Standalone/configurationdialog.ui" line="866"/>
        <location filename="src/Standalone/configurationdialog.ui" line="987"/>
        <source>ES2U_MAIN_018</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/configurationdialog.ui" line="763"/>
        <location filename="src/Standalone/configurationdialog.ui" line="882"/>
        <location filename="src/Standalone/configurationdialog.ui" line="1045"/>
        <source>ES2U_MAIN_019</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/configurationdialog.ui" line="828"/>
        <source>ES2U_MAIN_049</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/configurationdialog.ui" line="949"/>
        <source>ES2U_MAIN_017</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/configurationdialog.ui" line="1079"/>
        <location filename="src/Standalone/configurationdialog.ui" line="1402"/>
        <source>ES2U_MAIN_065</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/configurationdialog.ui" line="1131"/>
        <source>ES2U_MAIN_021</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/configurationdialog.ui" line="1143"/>
        <source>ES2U_MAIN_022</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/configurationdialog.ui" line="1166"/>
        <source>ES2U_MAIN_024</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/configurationdialog.ui" line="1178"/>
        <source>ES2U_MAIN_056</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/configurationdialog.ui" line="1211"/>
        <source>ES2U_MAIN_057</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/configurationdialog.ui" line="1282"/>
        <source>ES2U_SCANNER_012</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/configurationdialog.ui" line="1305"/>
        <source>ES2U_MAIN_061</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/configurationdialog.ui" line="1359"/>
        <source>ES2U_MAIN_027</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/configurationdialog.ui" line="1371"/>
        <source>ES2U_MAIN_062</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/configurationdialog.ui" line="1386"/>
        <source>ES2U_MAIN_064</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/configurationdialog.ui" line="1453"/>
        <source>ES2U_MAIN_063</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/configurationdialog.ui" line="1507"/>
        <source>0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/configurationdialog.ui" line="1514"/>
        <source>ES2U_SCANNER_001</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/configurationdialog.ui" line="1526"/>
        <source>ES2U_SCANNER_002</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/configurationdialog.ui" line="1587"/>
        <source>ES2U_SCANNER_007</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/configurationdialog.ui" line="1610"/>
        <source>ES2U_SCANNER_009</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/configurationdialog.ui" line="1645"/>
        <source>ES2U_MAIN_043</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/configurationdialog.ui" line="1657"/>
        <source>ES2U_MAIN_045</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/configurationdialog.ui" line="1670"/>
        <source>ES2U_MAIN_044</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/configurationdialog.ui" line="1704"/>
        <source>TC_PREVIEW_001</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/configurationdialog.ui" line="1720"/>
        <source>ES2U_MAIN_068</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/configurationdialog.ui" line="1723"/>
        <source>ES2U_MAIN_067</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ContinuousScanDialog</name>
    <message>
        <location filename="src/Standalone/continuousscandialog.ui" line="14"/>
        <source>COMMON_001</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/continuousscandialog.ui" line="40"/>
        <source>CONFIRMCONTINUE_005</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/continuousscandialog.ui" line="53"/>
        <source>CONFIRMCONTINUE_004</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/continuousscandialog.ui" line="66"/>
        <source>CONFIRMCONTINUE_003</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/continuousscandialog.ui" line="79"/>
        <source>CONFIRMCONTINUE_006</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/continuousscandialog.ui" line="98"/>
        <source>CONFIRMCONTINUE_008</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/continuousscandialog.ui" line="185"/>
        <source>CONFIRMCONTINUE_007</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DetectDoubleFeedSettingsDialog</name>
    <message>
        <location filename="src/Standalone/detectdoublefeedsettingsdialog.ui" line="14"/>
        <source>MAINSETTING_044</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/detectdoublefeedsettingsdialog.ui" line="30"/>
        <source>TC_PREVIEW_001</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/detectdoublefeedsettingsdialog.ui" line="43"/>
        <source>CONFIG_DOC_012</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/detectdoublefeedsettingsdialog.ui" line="66"/>
        <source>CONFIG_DOC_016</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/detectdoublefeedsettingsdialog.ui" line="92"/>
        <location filename="src/Standalone/detectdoublefeedsettingsdialog.ui" line="121"/>
        <source>EDGEFILLLEVEL_007</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/detectdoublefeedsettingsdialog.ui" line="136"/>
        <location filename="src/Standalone/detectdoublefeedsettingsdialog.ui" line="149"/>
        <source>EDGEFILLLEVEL_008</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DeviceConnectionDialog</name>
    <message>
        <location filename="src/Standalone/deviceconnectiondialog.ui" line="14"/>
        <source>COMMON_001</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/deviceconnectiondialog.ui" line="33"/>
        <source>SCANNERSETTING_013</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DeviceSelectDialog</name>
    <message>
        <location filename="src/Standalone/deviceselectdialog.ui" line="29"/>
        <source>MENU_001</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/deviceselectdialog.ui" line="51"/>
        <source>LINUX_DEVICESELECT_001</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/deviceselectdialog.ui" line="74"/>
        <source>LINUX_DEVICESELECT_002</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DocumentSizeDialog</name>
    <message>
        <location filename="src/Standalone/documentsizedialog.ui" line="14"/>
        <source>CUSTOMSIZE_001</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/documentsizedialog.ui" line="30"/>
        <source>CUSTOMSIZE_006</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/documentsizedialog.ui" line="43"/>
        <source>CUSTOMSIZE_007</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/documentsizedialog.ui" line="56"/>
        <source>CUSTOMSIZE_013</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/documentsizedialog.ui" line="69"/>
        <source>TC_PREVIEW_001</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/documentsizedialog.ui" line="95"/>
        <location filename="src/Standalone/documentsizedialog.ui" line="121"/>
        <source>CUSTOMSIZE_009</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/documentsizedialog.ui" line="139"/>
        <location filename="src/Standalone/documentsizedialog.ui" line="165"/>
        <source>CUSTOMSIZE_008</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/documentsizedialog.ui" line="255"/>
        <source>CUSTOMSIZE_010</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DocumentSizeSettingDialog</name>
    <message>
        <location filename="src/Standalone/documentsizesettingdialog.ui" line="14"/>
        <source>MAINSETTING_045</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/documentsizesettingdialog.ui" line="26"/>
        <source>MAINSETTING_86</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/documentsizesettingdialog.ui" line="39"/>
        <source>TC_PREVIEW_001</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DocumentSourceSettingsDialog</name>
    <message>
        <location filename="src/Standalone/documentsourcesettingsdialog.ui" line="14"/>
        <source>MAINSETTING_046</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/documentsourcesettingsdialog.ui" line="30"/>
        <source>TC_PREVIEW_001</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/documentsourcesettingsdialog.ui" line="43"/>
        <source>CONFIG_DOC_018</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/documentsourcesettingsdialog.ui" line="72"/>
        <source>:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EdgeCorrectionSettingsDialog</name>
    <message>
        <location filename="src/Standalone/edgecorrectionsettingsdialog.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/edgecorrectionsettingsdialog.ui" line="26"/>
        <source>ADVANCEDSETTING_116</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/edgecorrectionsettingsdialog.ui" line="39"/>
        <source>ADVANCEDSETTING_040</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/edgecorrectionsettingsdialog.ui" line="62"/>
        <source>EDGEFILLLEVEL_002</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/edgecorrectionsettingsdialog.ui" line="85"/>
        <location filename="src/Standalone/edgecorrectionsettingsdialog.ui" line="121"/>
        <location filename="src/Standalone/edgecorrectionsettingsdialog.ui" line="157"/>
        <location filename="src/Standalone/edgecorrectionsettingsdialog.ui" line="183"/>
        <source>EDGEFILLLEVEL_007</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/edgecorrectionsettingsdialog.ui" line="98"/>
        <source>EDGEFILLLEVEL_003</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/edgecorrectionsettingsdialog.ui" line="134"/>
        <location filename="src/Standalone/edgecorrectionsettingsdialog.ui" line="170"/>
        <source>EDGEFILLLEVEL_004</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/edgecorrectionsettingsdialog.ui" line="206"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/edgecorrectionsettingsdialog.ui" line="219"/>
        <source>ES2U_MAIN_046</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/edgecorrectionsettingsdialog.ui" line="232"/>
        <source>ES2U_MAIN_047</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FileNameSettingDialog</name>
    <message>
        <location filename="src/Standalone/filenamesettingdialog.ui" line="14"/>
        <source>FILENAMESETTING_001</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/filenamesettingdialog.ui" line="26"/>
        <source>TC_PREVIEW_001</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/filenamesettingdialog.ui" line="39"/>
        <source>FILENAMESETTING_007</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/filenamesettingdialog.ui" line="52"/>
        <source>FILENAMESETTING_016</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FocusPositionSettingDialog</name>
    <message>
        <location filename="src/Standalone/focuspositionsettingdialog.ui" line="14"/>
        <location filename="src/Standalone/focuspositionsettingdialog.ui" line="59"/>
        <source>MANUAL_FOCUSPOSITION_002</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/focuspositionsettingdialog.ui" line="30"/>
        <source>ES2U_MAIN_046</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/focuspositionsettingdialog.ui" line="43"/>
        <source>ES2U_MAIN_047</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/focuspositionsettingdialog.ui" line="66"/>
        <source>:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ImageEditDialog</name>
    <message>
        <location filename="src/Standalone/imageeditdialog.ui" line="14"/>
        <source>EDITPAGE_001</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/imageeditdialog.ui" line="111"/>
        <source>ADDPAGE_006</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/imageeditdialog.ui" line="127"/>
        <source>EDITPAGE_008</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/imageeditdialog.ui" line="174"/>
        <source>ADDPAGE_005</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ImageEditView</name>
    <message>
        <location filename="src/Standalone/imageeditview.cpp" line="1094"/>
        <source>画像ファイルを読み込めませんでした</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/imageeditview.cpp" line="1095"/>
        <source>Couldn&apos;t open the image</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ImageFormatSettingsDialog</name>
    <message>
        <location filename="src/Standalone/imageformatsettingsdialog.ui" line="14"/>
        <source>IMAGEFORMATOPTION_001</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/imageformatsettingsdialog.ui" line="30"/>
        <source>TC_PREVIEW_001</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/imageformatsettingsdialog.ui" line="71"/>
        <location filename="src/Standalone/imageformatsettingsdialog.ui" line="251"/>
        <location filename="src/Standalone/imageformatsettingsdialog.ui" line="513"/>
        <source>IMAGEFORMATOPTION_003</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/imageformatsettingsdialog.ui" line="86"/>
        <source>IMAGEFORMATOPTION_JPG_001</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/imageformatsettingsdialog.ui" line="99"/>
        <location filename="src/Standalone/imageformatsettingsdialog.ui" line="377"/>
        <source>IMAGEFORMATOPTION_JPG_005</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/imageformatsettingsdialog.ui" line="112"/>
        <location filename="src/Standalone/imageformatsettingsdialog.ui" line="390"/>
        <source>IMAGEFORMATOPTION_JPG_006</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/imageformatsettingsdialog.ui" line="147"/>
        <location filename="src/Standalone/imageformatsettingsdialog.ui" line="406"/>
        <source>IMAGEFORMATOPTION_JPG_004</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/imageformatsettingsdialog.ui" line="220"/>
        <source>IMAGEFORMATOPTION_JPG_003</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/imageformatsettingsdialog.ui" line="233"/>
        <source>IMAGEFORMATOPTION_JPG_002</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/imageformatsettingsdialog.ui" line="266"/>
        <source>IMAGEFORMATOPTION_TIF_010</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/imageformatsettingsdialog.ui" line="278"/>
        <source>IMAGEFORMATOPTION_TIF_009</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/imageformatsettingsdialog.ui" line="323"/>
        <source>IMAGEFORMATOPTION_PDF_004</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/imageformatsettingsdialog.ui" line="479"/>
        <source>IMAGEFORMATOPTION_PDF_006</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/imageformatsettingsdialog.ui" line="495"/>
        <source>IMAGEFORMATOPTION_PDF_005</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/imageformatsettingsdialog.ui" line="539"/>
        <source>IMAGEFORMATOPTION_002</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ImageTypeSettingsDialog</name>
    <message>
        <location filename="src/Standalone/imagetypesettingsdialog.ui" line="20"/>
        <source>MAINSETTING_073</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/imagetypesettingsdialog.ui" line="35"/>
        <source>MAINSETTING_082</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/imagetypesettingsdialog.ui" line="89"/>
        <source>TC_PREVIEW_001</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/imagetypesettingsdialog.ui" line="131"/>
        <source>MAINSETTING_074</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/imagetypesettingsdialog.ui" line="144"/>
        <source>MAINSETTING_083</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/imagetypesettingsdialog.ui" line="157"/>
        <source>MAINSETTING_084</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="src/Standalone/mainwindow.ui" line="26"/>
        <source>COMMON_001</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/mainwindow.ui" line="59"/>
        <source>MAINSETTING_001</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/mainwindow.ui" line="1066"/>
        <source>MAINSETTING_008</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/mainwindow.ui" line="1082"/>
        <source>MAINSETTING_002</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/mainwindow.ui" line="1111"/>
        <source>MAINSETTING_012</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/mainwindow.ui" line="1127"/>
        <source>MAINSETTING_019</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/mainwindow.ui" line="1143"/>
        <source>MAINSETTING_018</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/mainwindow.ui" line="1159"/>
        <source>MAINSETTING_020</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/mainwindow.ui" line="1175"/>
        <source>MAINSETTING_013</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/mainwindow.ui" line="1232"/>
        <source>MAINSETTING_050</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/mainwindow.ui" line="1235"/>
        <source>ADVANCEDSETTING_045</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/mainwindow.ui" line="1277"/>
        <source>CONFIG_DOC_003</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/mainwindow.ui" line="1293"/>
        <source>ADVANCEDSETTING_034</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/mainwindow.ui" line="1309"/>
        <source>MAINSETTING_053</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/mainwindow.ui" line="1325"/>
        <source>LINUX_MAINSETTING_002</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/mainwindow.ui" line="1328"/>
        <source>MAINSETTING_047</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/mainwindow.ui" line="1344"/>
        <source>MAINSETTING_052</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/mainwindow.ui" line="1504"/>
        <source>MAINSETTING_069</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/mainwindow.ui" line="1520"/>
        <source>MAINSETTING_068</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/mainwindow.ui" line="1552"/>
        <source>MAINSETTING_048</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/mainwindow.ui" line="1587"/>
        <source>MAINSETTING_007</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/mainwindow.ui" line="1628"/>
        <source>PHOTO_MAIN_007</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/mainwindow.ui" line="1647"/>
        <source>ADVANCEDSETTING_001</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/mainwindow.ui" line="1659"/>
        <source>ADVANCEDSETTING_004</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/mainwindow.ui" line="1717"/>
        <source>ADVANCEDSETTING_033</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/mainwindow.ui" line="1737"/>
        <source>ADVANCEDSETTING_077</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/mainwindow.ui" line="1783"/>
        <source>ADVANCEDSETTING_030</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/mainwindow.ui" line="1803"/>
        <source>PHOTO_ADVANCED_045</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/mainwindow.ui" line="1850"/>
        <source>ADVANCEDSETTING_031</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/mainwindow.ui" line="1870"/>
        <source>PHOTO_ADVANCED_046</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/mainwindow.ui" line="1920"/>
        <source>ADVANCEDSETTING_032</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/mainwindow.ui" line="1943"/>
        <source>ADVANCEDSETTING_076</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/mainwindow.ui" line="2032"/>
        <source>ADVANCEDSETTING_005</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/mainwindow.ui" line="2054"/>
        <source>ADVANCEDSETTING_068</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/mainwindow.ui" line="2057"/>
        <source>ADVANCEDSETTING_010</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/mainwindow.ui" line="2073"/>
        <source>ADVANCEDSETTING_065</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/mainwindow.ui" line="2076"/>
        <source>ADVANCEDSETTING_062</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/mainwindow.ui" line="2095"/>
        <source>ADVANCEDSETTING_066</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/mainwindow.ui" line="2098"/>
        <source>ADVANCEDSETTING_006</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/mainwindow.ui" line="2136"/>
        <source>ADVANCEDSETTING_083</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/mainwindow.ui" line="2154"/>
        <source>ADVANCEDSETTING_050</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/mainwindow.ui" line="2228"/>
        <source>ADVANCEDSETTING_114</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/mainwindow.ui" line="2281"/>
        <source>FILESAVESETTING_001</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/mainwindow.ui" line="2297"/>
        <source>FILESAVESETTING_010</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/mainwindow.ui" line="2313"/>
        <source>FILESAVESETTING_012</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/mainwindow.ui" line="2329"/>
        <source>LINUX_FILESAVESETTING_006</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/mainwindow.ui" line="2345"/>
        <source>CONFIG_001</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/mainwindow.ui" line="2389"/>
        <source>FILENAMESETTING_004</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/mainwindow.ui" line="2464"/>
        <source>COMMON_002</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/mainwindow.ui" line="2581"/>
        <source>FILESAVESETTING_018</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/mainwindow.ui" line="2597"/>
        <source>FILESAVESETTING_017</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/mainwindow.ui" line="2615"/>
        <source>SAVESETTING_003</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/mainwindow.ui" line="2681"/>
        <source>FILESAVESETTING_021</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/mainwindow.ui" line="2782"/>
        <source>ES2U_MAIN_004</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/mainwindow.ui" line="2792"/>
        <source>VERSION_001</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/mainwindow.ui" line="2797"/>
        <source>MENU_007</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>NetworkDeviceSelectDialog</name>
    <message>
        <location filename="src/Standalone/networkdeviceselectdialog.ui" line="14"/>
        <source>ADDNETSCANNER_001</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/networkdeviceselectdialog.ui" line="33"/>
        <source>SCANNERSETTING_010</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/networkdeviceselectdialog.ui" line="49"/>
        <source>ADDNETSCANNER_013</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/networkdeviceselectdialog.ui" line="65"/>
        <source>DELETESETTING_002</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/networkdeviceselectdialog.ui" line="94"/>
        <source>ADDNETSCANNER_012</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/networkdeviceselectdialog.ui" line="168"/>
        <source>ADDNETSCANNER_009</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/networkdeviceselectdialog.ui" line="190"/>
        <source>ADDNETSCANNER_014</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="38"/>
        <source>MAINSETTING_003</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="39"/>
        <source>MAINSETTING_004</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="40"/>
        <source>MAINSETTING_005</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="41"/>
        <source>MAINSETTING_006</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="42"/>
        <source>MAINSETTING_009</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="43"/>
        <source>MAINSETTING_010</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="44"/>
        <source>MAINSETTING_014</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="45"/>
        <source>MAINSETTING_015</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="46"/>
        <source>MAINSETTING_016</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="47"/>
        <source>MAINSETTING_017</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="48"/>
        <source>MAINSETTING_021</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="49"/>
        <source>MAINSETTING_022</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="50"/>
        <source>MAINSETTING_023</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="51"/>
        <source>MAINSETTING_024</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="52"/>
        <source>MAINSETTING_025</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="53"/>
        <source>MAINSETTING_031</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="54"/>
        <source>MAINSETTING_047</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="55"/>
        <source>MAINSETTING_075</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="56"/>
        <source>MAINSETTING_076</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="57"/>
        <source>MAINSETTING_077</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="58"/>
        <source>MAINSETTING_078</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="59"/>
        <source>MAINSETTING_081</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="60"/>
        <source>ADVANCEDSETTING_008</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="61"/>
        <source>ADVANCEDSETTING_009</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="62"/>
        <source>ADVANCEDSETTING_011</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="63"/>
        <source>ADVANCEDSETTING_012</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="64"/>
        <source>ADVANCEDSETTING_013</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="65"/>
        <source>ADVANCEDSETTING_050</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="66"/>
        <source>ADVANCEDSETTING_051</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="67"/>
        <source>ADVANCEDSETTING_052</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="68"/>
        <source>ADVANCEDSETTING_053</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="69"/>
        <source>ADVANCEDSETTING_054</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="70"/>
        <source>ADVANCEDSETTING_055</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="71"/>
        <source>ADVANCEDSETTING_059</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="72"/>
        <source>ADVANCEDSETTING_060</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="73"/>
        <source>ADVANCEDSETTING_061</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="74"/>
        <source>ADVANCEDSETTING_063</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="75"/>
        <source>ADVANCEDSETTING_064</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="76"/>
        <source>ADVANCEDSETTING_070</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="77"/>
        <source>ADVANCEDSETTING_072</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="78"/>
        <source>ADVANCEDSETTING_114</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="79"/>
        <source>AUTOFEEDMODE_005</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="80"/>
        <source>AUTOFEEDMODE_006</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="81"/>
        <source>AUTOFEEDMODE_007</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="82"/>
        <source>IMAGEFORMATOPTION_TIF_011</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="83"/>
        <source>IMAGEFORMATOPTION_TIF_012</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="84"/>
        <source>E_SCAN_001</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="85"/>
        <source>E_SCAN_003</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="86"/>
        <source>E_SCAN_101</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="87"/>
        <source>E_SCAN_102</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="88"/>
        <source>E_SCAN_103</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="89"/>
        <source>E_SCAN_104</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="90"/>
        <source>E_SCAN_105</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="91"/>
        <source>E_SCAN_107</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="92"/>
        <source>E_SCAN_109</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="93"/>
        <source>E_SCAN_110</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="94"/>
        <source>E_SCAN_111</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="95"/>
        <source>E_SCAN_113</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="96"/>
        <source>E_SCAN_114</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="97"/>
        <source>E_SCAN_117</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="98"/>
        <source>E_SCAN_118</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="99"/>
        <source>ES2U_MAIN_008</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="100"/>
        <source>ES2U_MAIN_025</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="101"/>
        <source>ES2U_MAIN_052</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="102"/>
        <source>ES2U_MAIN_053</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="103"/>
        <source>ES2U_SCANNER_003</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="104"/>
        <source>ES2U_SCANNER_004</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="105"/>
        <source>ES2U_SCANNER_005</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="106"/>
        <source>ES2U_SCANNER_008</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="107"/>
        <source>ES2U_SCANNER_010</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="108"/>
        <source>ES2U_SCANNER_011</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="109"/>
        <source>ES2U_SCANNER_012</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="110"/>
        <source>ES2U_SCANNER_013</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="111"/>
        <source>ES2U_SCANNER_014</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="112"/>
        <source>SIZELIST_NOSIZE_028</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="113"/>
        <source>SIZELIST_NOSIZE_030</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="114"/>
        <source>SIZELIST_NOSIZE_015</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="115"/>
        <source>SIZELIST_NOSIZE_016</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="116"/>
        <source>SIZELIST_NOSIZE_019</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="117"/>
        <source>SIZELIST_NOSIZE_025</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="118"/>
        <source>SIZELIST_NOSIZE_017</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="119"/>
        <source>SIZELIST_NOSIZE_018</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="120"/>
        <source>SIZELIST_NOSIZE_011</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="121"/>
        <source>SIZELIST_NOSIZE_012</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="122"/>
        <source>SIZELIST_NOSIZE_009</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="123"/>
        <source>SIZELIST_NOSIZE_010</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="124"/>
        <source>SIZELIST_NOSIZE_007</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="125"/>
        <source>SIZELIST_NOSIZE_008</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="126"/>
        <source>SIZELIST_NOSIZE_023</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="127"/>
        <source>SIZELIST_NOSIZE_024</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="128"/>
        <source>SIZELIST_NOSIZE_013</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="129"/>
        <source>SIZELIST_NOSIZE_014</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="130"/>
        <source>SIZELIST_NOSIZE_021</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="131"/>
        <source>SIZELIST_NOSIZE_001</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="132"/>
        <source>SIZELIST_NOSIZE_002</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="133"/>
        <source>SIZELIST_NOSIZE_003</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="134"/>
        <source>SIZELIST_NOSIZE_004</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="135"/>
        <source>SIZELIST_NOSIZE_027</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="136"/>
        <source>SIZELIST_NOSIZE_029</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="137"/>
        <source>SIZELIST_NOSIZE_031</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="138"/>
        <source>SIZELIST_NOSIZE_032</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="139"/>
        <source>SIZELIST_NOSIZE_038</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="140"/>
        <source>SIZELIST_NOSIZE_039</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="141"/>
        <source>SIZELIST_NOSIZE_040</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="142"/>
        <source>SIZELIST_NOSIZE_041</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="143"/>
        <source>SIZELIST_NOSIZE_042</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="144"/>
        <source>SIZELIST_NOSIZE_043</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="145"/>
        <source>A_UI_003</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="146"/>
        <source>A_UI_005</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="147"/>
        <source>A_UI_006</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="148"/>
        <source>A_SCAN_001</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="149"/>
        <source>A_UNIT_001</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="150"/>
        <source>A_UNIT_007</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="151"/>
        <source>A_UNIT_008</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="152"/>
        <source>A_UNIT_015</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="153"/>
        <source>A_UNIT_009</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="154"/>
        <source>C_UI_002</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="155"/>
        <source>C_UI_004</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="156"/>
        <source>C_UI_005</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="157"/>
        <source>C_UI_006</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="158"/>
        <source>C_UI_101</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="159"/>
        <source>C_UI_102</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="160"/>
        <source>C_UNIT_001</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="161"/>
        <source>C_UNIT_002</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="162"/>
        <source>C_UNIT_003</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="163"/>
        <source>E_UI_103</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="164"/>
        <source>E_UI_109</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="165"/>
        <source>E_SAVE_001</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="166"/>
        <source>E_SAVE_004</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="167"/>
        <source>E_COMM_001</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="168"/>
        <source>E_COMM_102</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="169"/>
        <source>E_COMM_103</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="170"/>
        <source>E_UNIT_008</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="171"/>
        <source>E_UNIT_009</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="172"/>
        <source>E_UNIT_010</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="173"/>
        <source>E_UNIT_011</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="174"/>
        <source>E_ENV_001</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="175"/>
        <source>E_PARA_001</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="176"/>
        <source>E_PARA_005</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="177"/>
        <source>E_PARA_003</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="178"/>
        <source>E_PARA_011</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="179"/>
        <source>E_PARA_013</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="180"/>
        <source>CUSTOMSIZE_008</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="181"/>
        <source>CUSTOMSIZE_009</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="182"/>
        <source>CUSTOMSIZE_010</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="183"/>
        <source>CONFIG_GENERAL_003</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="184"/>
        <source>CONFIG_GENERAL_004</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="185"/>
        <source>CONFIG_DOC_004</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="186"/>
        <source>CONFIG_DOC_005</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="187"/>
        <source>CONFIG_DOC_010</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="188"/>
        <source>CONFIG_DOC_013</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="189"/>
        <source>CONFIG_DOC_014</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="190"/>
        <source>CONFIG_DOC_019</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="191"/>
        <source>CONFIG_DOC_020</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="192"/>
        <source>CONFIG_DOC_021</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="193"/>
        <source>CONFIG_DOC_022</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="194"/>
        <source>CONFIG_DOC_023</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="195"/>
        <source>CONFIG_DOC_024</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="196"/>
        <source>CONFIG_SCAN_008</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="197"/>
        <source>CONFIG_SCAN_009</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="198"/>
        <source>PROGRESS_003</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="199"/>
        <source>PROGRESS_005</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="200"/>
        <source>PROGRESS_007</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="201"/>
        <source>PROGRESS_008</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="202"/>
        <source>FILESAVESETTING_003</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="203"/>
        <source>FILESAVESETTING_004</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="204"/>
        <source>FILESAVESETTING_005</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="205"/>
        <source>FILESAVESETTING_006</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="206"/>
        <source>FILESAVESETTING_007</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="207"/>
        <source>FILESAVESETTING_009</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="208"/>
        <source>FILESAVESETTING_016</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="209"/>
        <source>FILESAVESETTING_012</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="210"/>
        <source>MENU_001</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="211"/>
        <source>SCANNERSETTING_005</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="212"/>
        <source>SCANNERSETTING_006</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="213"/>
        <source>VERSION_003</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="214"/>
        <source>CONFIRMCONTINUE_002</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="215"/>
        <source>CONFIRMCONTINUE_003</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="216"/>
        <source>CONFIRMCONTINUE_004</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="217"/>
        <source>CONFIRMCONTINUE_005</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="218"/>
        <source>CONFIRMCONTINUE_008</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="219"/>
        <source>CONFIRMCONTINUE_011</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="220"/>
        <source>CONFIRMCONTINUE_013</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="221"/>
        <source>CONFIRMCONTINUE_014</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="222"/>
        <source>CONFIRMCONTINUE_015</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="223"/>
        <source>LINUX_E_COMM_001</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="224"/>
        <source>LINUX_C_UI_001</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="225"/>
        <source>LINUX_C_UI_002</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="226"/>
        <source>LINUX_DEVICESELECT_003</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="227"/>
        <source>LINUX_SIZELIST_NOSIZE_001</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="228"/>
        <source>LINUX_FILESAVESETTING_001</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="229"/>
        <source>LINUX_FILESAVESETTING_002</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="230"/>
        <source>LINUX_FILESAVESETTING_003</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="231"/>
        <source>LINUX_FILESAVESETTING_004</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="232"/>
        <source>LINUX_FILESAVESETTING_005</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="233"/>
        <source>LINUX_FILESAVESETTING_006</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="234"/>
        <source>LINUX_FILESAVESETTING_007</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="235"/>
        <source>LINUX_FILESAVESETTING_008</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="236"/>
        <source>LINUX_FILESAVESETTING_009</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="237"/>
        <source>LINUX_MAINSETTING_001</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="238"/>
        <source>PHOTO_MAIN_008</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="239"/>
        <source>PHOTO_MAIN_009</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="240"/>
        <source>PHOTO_MAIN_010</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="241"/>
        <source>PHOTO_MAIN_013</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="242"/>
        <source>PHOTO_MAIN_019</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/translationstring.cpp" line="243"/>
        <source>PHOTO_MAIN_020</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ScanningDialog</name>
    <message>
        <location filename="src/Standalone/scanningdialog.ui" line="14"/>
        <source>PROGRESS_001</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/scanningdialog.ui" line="55"/>
        <source>PROGRESS_017</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/scanningdialog.ui" line="68"/>
        <source>PROGRESS_008</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SkipBlankPagesSettingsDialog</name>
    <message>
        <location filename="src/Standalone/skipblankpagessettingsdialog.ui" line="14"/>
        <source>ADVANCEDSETTING_056</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/skipblankpagessettingsdialog.ui" line="30"/>
        <source>TC_PREVIEW_001</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/skipblankpagessettingsdialog.ui" line="66"/>
        <source>ADVANCEDSETTING_058</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TextEnhanceSettingDialog</name>
    <message>
        <location filename="src/Standalone/textenhancesettingdialog.ui" line="14"/>
        <source>ADVANCEDSETTING_084</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/textenhancesettingdialog.ui" line="29"/>
        <source>ADVANCEDSETTING_089</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/textenhancesettingdialog.ui" line="49"/>
        <location filename="src/Standalone/textenhancesettingdialog.ui" line="119"/>
        <location filename="src/Standalone/textenhancesettingdialog.ui" line="189"/>
        <source>ADVANCEDSETTING_077</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/textenhancesettingdialog.ui" line="99"/>
        <source>ADVANCEDSETTING_086</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/textenhancesettingdialog.ui" line="169"/>
        <source>ADVANCEDSETTING_087</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/textenhancesettingdialog.ui" line="236"/>
        <source>ADVANCEDSETTING_088</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/textenhancesettingdialog.ui" line="249"/>
        <source>TC_PREVIEW_001</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WaitingDialog</name>
    <message>
        <location filename="src/Standalone/waitingdialog.ui" line="14"/>
        <source>MENU_001</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>addeditpageDialog</name>
    <message>
        <location filename="src/Standalone/addeditpagedialog.ui" line="14"/>
        <source>ADDPAGE_001</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/addeditpagedialog.ui" line="30"/>
        <source>ADDPAGE_002</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/addeditpagedialog.ui" line="43"/>
        <source>ADDPAGE_003</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/addeditpagedialog.ui" line="56"/>
        <source>ADDPAGE_004</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/addeditpagedialog.ui" line="72"/>
        <source>ADDPAGE_007</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/addeditpagedialog.ui" line="88"/>
        <source>ADDPAGE_006</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/Standalone/addeditpagedialog.ui" line="101"/>
        <source>ADDPAGE_005</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
